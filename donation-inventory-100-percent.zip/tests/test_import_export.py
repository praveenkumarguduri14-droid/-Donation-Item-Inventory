"""Tests for import and export functionality across CSV, JSON, Markdown, and TXT."""

import csv
import json
from pathlib import Path
import tempfile
import unittest

from donation_inventory.database import DatabaseManager
from donation_inventory.services import InventoryService
from donation_inventory.validators import ValidationError


class TestImportExport(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.service = InventoryService(self.db)
        self.temp_dir = tempfile.TemporaryDirectory()
        self.tmp = Path(self.temp_dir.name)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_export_and_import_csv(self):
        self.service.add_item("Rice 10kg", "Food", 50, "Asha Foundation", "2026-11-01", "2027-01-01")
        self.service.add_item("Winter Coats", "Clothing", 25, "Rotary Club", "2026-11-05", None)

        csv_file = self.tmp / "inventory.csv"
        exported_path = self.service.export_csv(csv_file)
        self.assertTrue(Path(exported_path).exists())

        # Wipe and import back
        self.service.wipe_all_data()
        self.assertEqual(len(self.service.items_repo.get_all()), 0)

        # Create valid import CSV
        import_csv_file = self.tmp / "import.csv"
        with open(import_csv_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["name", "category", "quantity", "donor", "date", "expiry"])
            writer.writerow(["Textbooks", "Books", 100, "City Library", "2026-11-10", ""])
            writer.writerow(["Bandages", "Medical", 200, "Hospital", "2026-11-12", "2028-12-31"])

        imported, errs = self.service.import_csv(import_csv_file)
        self.assertEqual(imported, 2)
        self.assertEqual(len(errs), 0)
        self.assertEqual(len(self.service.items_repo.get_all()), 2)

    def test_import_csv_with_errors(self):
        csv_file = self.tmp / "import_errors.csv"
        with open(csv_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["name", "category", "quantity", "donor", "date", "expiry"])
            # Row 2: valid
            writer.writerow(["Blankets", "Household", 15, "Rotary", "2026-11-10", ""])
            # Row 3: invalid quantity (-5)
            writer.writerow(["Invalid Qty", "Household", -5, "Rotary", "2026-11-10", ""])
            # Row 4: invalid category
            writer.writerow(["Bad Category", "Cars", 10, "Rotary", "2026-11-10", ""])

        imported, errs = self.service.import_csv(csv_file)
        self.assertEqual(imported, 1)
        self.assertEqual(len(errs), 2)
        self.assertTrue("Row 3" in errs[0])
        self.assertTrue("Row 4" in errs[1])

    def test_import_csv_missing_columns(self):
        csv_file = self.tmp / "missing_cols.csv"
        with open(csv_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["name", "quantity"])
            writer.writerow(["Blankets", 15])

        with self.assertRaises(ValidationError):
            self.service.import_csv(csv_file)

    def test_export_json_roundtrip(self):
        it = self.service.add_item("Rice", "Food", 100, "Donor", "2026-11-01")
        self.service.record_distribution(it.id, 20, "Family", "2026-11-05")

        json_file = self.tmp / "backup.json"
        self.service.export_json(json_file)

        with open(json_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        self.assertIn("items", data)
        self.assertIn("distributions", data)
        self.assertEqual(len(data["items"]), 1)
        self.assertEqual(len(data["distributions"]), 1)
        self.assertEqual(data["items"][0]["name"], "Rice")

    def test_export_markdown(self):
        self.service.add_item("Soap", "Hygiene", 50, "Donor", "2026-11-01")
        md_file = self.tmp / "summary.md"
        self.service.export_markdown(md_file)
        self.assertTrue(md_file.exists())
        content = md_file.read_text(encoding="utf-8")
        self.assertIn("# Donation Item Inventory Summary Report", content)
        self.assertIn("Hygiene", content)

    def test_export_audit_log(self):
        it = self.service.add_item("Batteries", "Electronics", 60, "Donor", "2026-11-01")
        self.service.record_distribution(it.id, 10, "School", "2026-11-02")
        txt_file = self.tmp / "audit.txt"
        self.service.export_audit_log(txt_file)
        self.assertTrue(txt_file.exists())
        content = txt_file.read_text(encoding="utf-8")
        self.assertIn("DONATIONS RECEIVED", content)
        self.assertIn("DISTRIBUTIONS GIVEN OUT", content)
        self.assertIn("Batteries", content)


if __name__ == "__main__":
    unittest.main()
