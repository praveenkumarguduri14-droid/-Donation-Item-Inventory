"""Tests for business logic, services, analytics, and stock distribution."""

from datetime import date
import unittest

from donation_inventory.database import DatabaseManager
from donation_inventory.models import ItemStatus
from donation_inventory.services import InventoryService
from donation_inventory.validators import (
    NotFoundError,
    ValidationError,
)


class TestServices(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.service = InventoryService(self.db)
        self.today = date(2026, 11, 21)

    def test_add_and_list_item(self):
        item = self.service.add_item(
            name="Warm Jackets",
            category="Clothing",
            quantity=50,
            donor="Lions Club",
            date_received="2026-11-10",
            current_date=self.today,
        )
        self.assertEqual(item.name, "Warm Jackets")
        self.assertEqual(item.stock, 50)
        self.assertEqual(item.category, "Clothing")

        items, total = self.service.list_items()
        self.assertEqual(total, 1)
        self.assertEqual(items[0].id, item.id)

    def test_search_and_filters(self):
        self.service.add_item("Rice sacks", "Food", 100, "Green Valley", "2026-11-01", current_date=self.today)
        self.service.add_item("Toy cars", "Toys", 5, "Green Valley", "2026-11-01", current_date=self.today)
        self.service.add_item("Math Books", "Books", 50, "City Library", "2026-11-01", current_date=self.today)

        # Search by donor
        results, total = self.service.list_items(search="Green Valley")
        self.assertEqual(total, 2)

        # Search by name
        results, total = self.service.list_items(search="Math")
        self.assertEqual(total, 1)
        self.assertEqual(results[0].name, "Math Books")

        # Filter by category
        results, total = self.service.list_items(category="Toys")
        self.assertEqual(total, 1)

        # Filter by status (Toy cars has stock 5 <= 10 -> Low stock)
        results, total = self.service.list_items(status="Low stock", current_date=self.today)
        self.assertEqual(total, 1)
        self.assertEqual(results[0].name, "Toy cars")

    def test_record_distribution_success(self):
        item = self.service.add_item("Blankets", "Clothing", 40, "Rotary", "2026-11-01", current_date=self.today)
        dist = self.service.record_distribution(
            item_id=item.id,
            quantity=15,
            recipient="Shelter Home",
            date_given="2026-11-05",
            current_date=self.today,
        )
        self.assertEqual(dist.quantity, 15)
        self.assertEqual(dist.recipient, "Shelter Home")

        # Check updated stock
        updated_item = self.service.get_item(item.id)
        self.assertEqual(updated_item.stock, 25)

        # Check distribution log
        logs = self.service.list_distributions()
        self.assertEqual(len(logs), 1)
        self.assertEqual(logs[0].item_name, "Blankets")

    def test_distribution_stock_depletion_edge_case(self):
        item = self.service.add_item("Stethoscope", "Medical", 5, "Dr. Smith", "2026-11-01", current_date=self.today)
        self.service.record_distribution(item.id, 5, "Clinic", "2026-11-02", current_date=self.today)

        updated = self.service.get_item(item.id)
        self.assertEqual(updated.stock, 0)
        self.assertEqual(updated.calculate_status(self.today), ItemStatus.OUT_OF_STOCK)

    def test_distribution_exceeding_stock_raises_error(self):
        item = self.service.add_item("Tablets", "Electronics", 10, "Tech Org", "2026-11-01", current_date=self.today)
        with self.assertRaises(ValidationError):
            self.service.record_distribution(item.id, 11, "School", "2026-11-02", current_date=self.today)

    def test_delete_item(self):
        item = self.service.add_item("Pencils", "Books", 50, "Donor", "2026-11-01", current_date=self.today)
        self.service.delete_item(item.id)
        with self.assertRaises(NotFoundError):
            self.service.get_item(item.id)

    def test_get_stats_empty(self):
        stats = self.service.get_stats(self.today)
        self.assertEqual(stats.total_lines, 0)
        self.assertEqual(stats.units_received, 0)
        self.assertEqual(stats.units_in_stock, 0)
        self.assertEqual(stats.units_given_out, 0)
        self.assertEqual(stats.distribution_rate_pct, 0.0)
        self.assertIsNone(stats.top_donor)

    def test_get_stats_with_data(self):
        item1 = self.service.add_item("Item 1", "Food", 100, "Donor Alpha", "2026-11-01", current_date=self.today)
        item2 = self.service.add_item("Item 2", "Clothing", 50, "Donor Beta", "2026-11-01", current_date=self.today)

        self.service.record_distribution(item1.id, 30, "Shelter", "2026-11-05", current_date=self.today)

        stats = self.service.get_stats(self.today)
        self.assertEqual(stats.total_lines, 2)
        self.assertEqual(stats.units_received, 150)
        self.assertEqual(stats.units_given_out, 30)
        self.assertEqual(stats.units_in_stock, 120)
        self.assertEqual(stats.distribution_rate_pct, 20.0)  # 30 / 150 * 100 = 20%
        self.assertEqual(stats.top_donor, ("Donor Alpha", 100))

    def test_seed_sample_data(self):
        count = self.service.seed_sample_data()
        self.assertEqual(count, 40)
        items, total = self.service.list_items(page_size=100)
        self.assertEqual(total, 40)

        # Ensure distributions were created during seed
        dists = self.service.list_distributions()
        self.assertGreater(len(dists), 0)

        # Check stats after seed
        stats = self.service.get_stats()
        self.assertGreater(stats.units_given_out, 0)
        self.assertGreater(stats.units_in_stock, 0)


if __name__ == "__main__":
    unittest.main()
