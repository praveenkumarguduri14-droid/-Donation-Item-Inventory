"""Tests for SQLite persistence, transactions, and foreign key cascades."""

import unittest

from donation_inventory.database import (
    DatabaseManager,
    DistributionRepository,
    ItemRepository,
)
from donation_inventory.models import Distribution, Item


class TestDatabase(unittest.TestCase):
    def setUp(self):
        # Use in-memory SQLite database for high-speed, isolated testing
        self.db = DatabaseManager(":memory:")
        self.items_repo = ItemRepository(self.db)
        self.dist_repo = DistributionRepository(self.db)

    def test_create_and_get_item(self):
        item = Item(
            id=None,
            name="Rice bags",
            category="Food",
            received=100,
            stock=100,
            donor="Green Valley",
            date_received="2026-11-01",
            expiry_date="2027-01-01",
        )
        saved = self.items_repo.create(item)
        self.assertIsNotNone(saved.id)

        retrieved = self.items_repo.get_by_id(saved.id)
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.name, "Rice bags")
        self.assertEqual(retrieved.stock, 100)

    def test_update_stock(self):
        item = self.items_repo.create(
            Item(None, "Blanket", "Clothing", 50, 50, "Donor X", "2026-11-01", None)
        )
        ok = self.items_repo.update_stock(item.id, 35)
        self.assertTrue(ok)
        updated = self.items_repo.get_by_id(item.id)
        self.assertEqual(updated.stock, 35)

    def test_delete_item_with_foreign_key_cascade(self):
        item = self.items_repo.create(
            Item(None, "Jackets", "Clothing", 20, 20, "Donor Y", "2026-11-01", None)
        )
        dist = self.dist_repo.create(
            Distribution(None, item.id, item.name, 5, "Shelter", "2026-11-05")
        )
        self.assertIsNotNone(dist.id)

        # Confirm distribution exists
        dists = self.dist_repo.get_all()
        self.assertEqual(len(dists), 1)

        # Delete item line
        self.items_repo.delete(item.id)

        # Item should be gone
        self.assertIsNone(self.items_repo.get_by_id(item.id))
        # Cascaded distribution should also be deleted
        dists_after = self.dist_repo.get_all()
        self.assertEqual(len(dists_after), 0)

    def test_clear_all(self):
        self.items_repo.create(
            Item(None, "Toy A", "Toys", 10, 10, "Donor", "2026-11-01", None)
        )
        self.items_repo.create(
            Item(None, "Toy B", "Toys", 10, 10, "Donor", "2026-11-01", None)
        )
        self.assertEqual(len(self.items_repo.get_all()), 2)

        self.items_repo.clear_all()
        self.assertEqual(len(self.items_repo.get_all()), 0)


if __name__ == "__main__":
    unittest.main()
