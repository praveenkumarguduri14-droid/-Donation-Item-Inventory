"""Tests for input validation, boundary values, and security sanitization."""

from datetime import date, timedelta
import unittest

from donation_inventory.models import Item
from donation_inventory.validators import (
    parse_date,
    sanitize_formula_injection,
    validate_distribution_data,
    validate_item_data,
)


class TestValidators(unittest.TestCase):
    def setUp(self):
        self.today = date(2026, 11, 21)

    def test_valid_item_data(self):
        errs = validate_item_data(
            name="Winter Jackets",
            category="Clothing",
            quantity=50,
            donor="Rotary Club",
            date_received="2026-11-15",
            expiry_date=None,
            current_date=self.today,
        )
        self.assertEqual(errs, [])

    def test_item_name_length_boundaries(self):
        # Too short (< 2)
        errs = validate_item_data("A", "Food", 10, "Donor", "2026-11-15", current_date=self.today)
        self.assertTrue(any("name must be between 2 and 60" in e for e in errs))

        # Exactly 2 (valid)
        errs = validate_item_data("AB", "Food", 10, "Donor", "2026-11-15", current_date=self.today)
        self.assertEqual(errs, [])

        # Exactly 60 (valid)
        errs = validate_item_data("A" * 60, "Food", 10, "Donor", "2026-11-15", current_date=self.today)
        self.assertEqual(errs, [])

        # Too long (> 60)
        errs = validate_item_data("A" * 61, "Food", 10, "Donor", "2026-11-15", current_date=self.today)
        self.assertTrue(any("name must be between 2 and 60" in e for e in errs))

    def test_invalid_category(self):
        errs = validate_item_data("Blanket", "Automotive", 10, "Donor", "2026-11-15", current_date=self.today)
        self.assertTrue(any("Category must be one of" in e for e in errs))

    def test_quantity_boundaries(self):
        # Negative / zero
        errs = validate_item_data("Blanket", "Household", 0, "Donor", "2026-11-15", current_date=self.today)
        self.assertTrue(any("Quantity must be a whole number" in e for e in errs))

        # Max allowed (100,000)
        errs = validate_item_data("Blanket", "Household", 100_000, "Donor", "2026-11-15", current_date=self.today)
        self.assertEqual(errs, [])

        # Exceeds max (100,001)
        errs = validate_item_data("Blanket", "Household", 100_001, "Donor", "2026-11-15", current_date=self.today)
        self.assertTrue(any("Quantity must be a whole number" in e for e in errs))

        # Non-numeric
        errs = validate_item_data("Blanket", "Household", "abc", "Donor", "2026-11-15", current_date=self.today)
        self.assertTrue(any("Quantity must be a valid whole number" in e for e in errs))

    def test_date_received_rules(self):
        # Future date
        future = (self.today + timedelta(days=1)).isoformat()
        errs = validate_item_data("Blanket", "Household", 10, "Donor", future, current_date=self.today)
        self.assertTrue(any("cannot be in the future" in e for e in errs))

        # Malformed date
        errs = validate_item_data("Blanket", "Household", 10, "Donor", "15-11-2026", current_date=self.today)
        self.assertTrue(any("must be a valid date in YYYY-MM-DD" in e for e in errs))

    def test_expiry_date_rules(self):
        # Expiry before received date
        errs = validate_item_data(
            "Canned Soup", "Food", 10, "Donor", "2026-11-15",
            expiry_date="2026-11-10", current_date=self.today
        )
        self.assertTrue(any("cannot be before the date received" in e for e in errs))

        # Expiry equal or after received date
        errs = validate_item_data(
            "Canned Soup", "Food", 10, "Donor", "2026-11-15",
            expiry_date="2026-11-20", current_date=self.today
        )
        self.assertEqual(errs, [])

    def test_distribution_validation(self):
        item = Item(
            id=1,
            name="Blankets",
            category="Clothing",
            received=50,
            stock=20,
            donor="Donor A",
            date_received="2026-11-10",
        )

        # Valid distribution
        errs = validate_distribution_data(item, 10, "Community Shelter", "2026-11-15", current_date=self.today)
        self.assertEqual(errs, [])

        # Exceeding available stock
        errs = validate_distribution_data(item, 25, "Community Shelter", "2026-11-15", current_date=self.today)
        self.assertTrue(any("Insufficient stock" in e for e in errs))

        # Zero or negative distribution
        errs = validate_distribution_data(item, 0, "Community Shelter", "2026-11-15", current_date=self.today)
        self.assertTrue(any("at least 1" in e for e in errs))

        # Date before received
        errs = validate_distribution_data(item, 5, "Community Shelter", "2026-11-05", current_date=self.today)
        self.assertTrue(any("cannot be before the item's received date" in e for e in errs))

        # Future distribution date
        future = (self.today + timedelta(days=2)).isoformat()
        errs = validate_distribution_data(item, 5, "Community Shelter", future, current_date=self.today)
        self.assertTrue(any("cannot be in the future" in e for e in errs))

        # None item
        errs = validate_distribution_data(None, 5, "Community Shelter", "2026-11-15", current_date=self.today)
        self.assertTrue(any("valid item must be selected" in e for e in errs))

    def test_formula_injection_sanitization(self):
        self.assertEqual(sanitize_formula_injection("Normal Text"), "Normal Text")
        self.assertEqual(sanitize_formula_injection("=cmd|'/C calc'!A0"), "'=cmd|'/C calc'!A0")
        self.assertEqual(sanitize_formula_injection("+1234"), "'+1234")
        self.assertEqual(sanitize_formula_injection("-5+5"), "'-5+5")
        self.assertEqual(sanitize_formula_injection("@SUM(1,2)"), "'@SUM(1,2)")


if __name__ == "__main__":
    unittest.main()
