"""End-to-end tests for CLI execution and argument handling."""

import io
from pathlib import Path
import sys
import tempfile
import unittest

from donation_inventory.cli import InventoryCLI
from donation_inventory.database import DatabaseManager
from donation_inventory.services import InventoryService


class TestCLI(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.service = InventoryService(self.db)
        self.cli = InventoryCLI(self.service)
        self.temp_dir = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_cli_add_and_list(self):
        # Test CLI add
        ret = self.cli.run([
            "add",
            "--name", "Rice Bags",
            "--category", "Food",
            "--quantity", "100",
            "--donor", "Asha Foundation",
            "--date", "2026-11-10",
        ])
        self.assertEqual(ret, 0)

        # Test CLI list
        ret = self.cli.run(["list"])
        self.assertEqual(ret, 0)

    def test_cli_distribute_and_history(self):
        # Add item first
        it = self.service.add_item("Blankets", "Clothing", 50, "Rotary", "2026-11-01")

        # Distribute via CLI
        ret = self.cli.run([
            "distribute",
            "--item-id", str(it.id),
            "--quantity", "20",
            "--recipient", "Shelter",
            "--date", "2026-11-05",
        ])
        self.assertEqual(ret, 0)

        # Check updated stock
        updated = self.service.get_item(it.id)
        self.assertEqual(updated.stock, 30)

        # View history
        ret = self.cli.run(["history"])
        self.assertEqual(ret, 0)

    def test_cli_summary(self):
        self.service.seed_sample_data()
        ret = self.cli.run(["summary"])
        self.assertEqual(ret, 0)

    def test_cli_seed_and_wipe(self):
        ret = self.cli.run(["seed"])
        self.assertEqual(ret, 0)
        items, count = self.service.list_items()
        self.assertEqual(count, 40)

        ret = self.cli.run(["wipe", "--confirm"])
        self.assertEqual(ret, 0)
        items, count = self.service.list_items()
        self.assertEqual(count, 0)

    def test_cli_export(self):
        self.service.add_item("Soap", "Hygiene", 30, "Donor", "2026-11-01")
        csv_out = Path(self.temp_dir.name) / "cli_export.csv"
        ret = self.cli.run(["export", "--format", "csv", "--output", str(csv_out)])
        self.assertEqual(ret, 0)
        self.assertTrue(csv_out.exists())

    def test_cli_validation_failure(self):
        # Quantity out of bounds
        ret = self.cli.run([
            "add",
            "--name", "Rice",
            "--category", "Food",
            "--quantity", "0",
            "--donor", "Donor",
        ])
        self.assertEqual(ret, 1)


if __name__ == "__main__":
    unittest.main()
