"""Tests for domain models, status calculations, and entity serialization."""

from datetime import date, timedelta
import unittest

from donation_inventory.models import (
    Category,
    Distribution,
    Item,
    ItemStatus,
    LOW_STOCK_THRESHOLD,
    MAX_QUANTITY,
)


class TestModels(unittest.TestCase):
    def setUp(self):
        self.today = date(2026, 11, 21)

    def test_category_enumeration(self):
        self.assertEqual(len(Category.list()), 8)
        self.assertTrue(Category.has_value("Food"))
        self.assertTrue(Category.has_value("food"))
        self.assertTrue(Category.has_value("  MEDICAL  "))
        self.assertFalse(Category.has_value("Vehicle"))
        self.assertEqual(Category.from_str("clothing"), Category.CLOTHING)
        with self.assertRaises(ValueError):
            Category.from_str("Unknown")

    def test_item_status_in_stock(self):
        item = Item(
            id=1,
            name="Rice",
            category="Food",
            received=50,
            stock=45,
            donor="John",
            date_received="2026-11-01",
            expiry_date="2027-05-01",
        )
        self.assertEqual(item.calculate_status(self.today), ItemStatus.IN_STOCK)

    def test_item_status_out_of_stock(self):
        item = Item(
            id=2,
            name="Blankets",
            category="Clothing",
            received=20,
            stock=0,
            donor="Rotary",
            date_received="2026-11-01",
        )
        self.assertEqual(item.calculate_status(self.today), ItemStatus.OUT_OF_STOCK)

    def test_item_status_low_stock(self):
        item = Item(
            id=3,
            name="First Aid Kit",
            category="Medical",
            received=20,
            stock=LOW_STOCK_THRESHOLD,
            donor="Red Cross",
            date_received="2026-11-01",
            expiry_date="2027-12-01",
        )
        self.assertEqual(item.calculate_status(self.today), ItemStatus.LOW_STOCK)

    def test_item_status_expiring_soon(self):
        # Within 30 days
        soon_date = (self.today + timedelta(days=15)).isoformat()
        item = Item(
            id=4,
            name="Milk Cans",
            category="Food",
            received=50,
            stock=40,
            donor="Bakery",
            date_received="2026-11-01",
            expiry_date=soon_date,
        )
        self.assertEqual(item.calculate_status(self.today), ItemStatus.EXPIRING_SOON)

    def test_item_status_expired(self):
        # Expiry strictly before current date
        past_date = (self.today - timedelta(days=2)).isoformat()
        item = Item(
            id=5,
            name="Bread",
            category="Food",
            received=30,
            stock=15,
            donor="Bakery",
            date_received="2026-11-01",
            expiry_date=past_date,
        )
        self.assertEqual(item.calculate_status(self.today), ItemStatus.EXPIRED)

    def test_expired_with_zero_stock_is_out_of_stock_or_expired(self):
        # When stock is 0 and expired, stock == 0 check or expiry check
        # Our rule specifies: if expired and stock > 0 => Expired; if stock == 0 => Out of stock
        past_date = (self.today - timedelta(days=2)).isoformat()
        item = Item(
            id=6,
            name="Bread",
            category="Food",
            received=30,
            stock=0,
            donor="Bakery",
            date_received="2026-11-01",
            expiry_date=past_date,
        )
        self.assertEqual(item.calculate_status(self.today), ItemStatus.OUT_OF_STOCK)

    def test_item_to_dict(self):
        item = Item(
            id=10,
            name="Notebooks",
            category="Books",
            received=100,
            stock=80,
            donor="School",
            date_received="2026-11-10",
        )
        d = item.to_dict()
        self.assertEqual(d["id"], 10)
        self.assertEqual(d["name"], "Notebooks")
        self.assertEqual(d["status"], "In stock")

    def test_distribution_to_dict(self):
        dist = Distribution(
            id=1,
            item_id=10,
            item_name="Notebooks",
            quantity=20,
            recipient="Primary School",
            date_given="2026-11-15",
        )
        d = dist.to_dict()
        self.assertEqual(d["item_id"], 10)
        self.assertEqual(d["quantity"], 20)


if __name__ == "__main__":
    unittest.main()
