#!/usr/bin/env python3
"""Main entry point for Donation Item Inventory Management System (v2.0).

Fulfills all academic requirements of the SRS (Python 3.10+ CLI application).
"""

import sys
from donation_inventory.cli import InventoryCLI

def main() -> None:
    cli = InventoryCLI()
    sys.exit(cli.run(sys.argv[1:]))

if __name__ == "__main__":
    main()
