"use strict";
/* ---------- Config & state ---------- */
const KEY = "donationInventory.v1";
const CATEGORIES = ["Food", "Clothing", "Medical", "Books", "Toys", "Hygiene", "Electronics", "Household"];
const LOW_LIMIT = 10, SOON_DAYS = 30, PAGE_SIZE = 10, MAX_QTY = 100000;
let db = load();
let page = 1;

const $ = id => document.getElementById(id);
const today = () => new Date().toISOString().slice(0, 10);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* ---------- Persistence (with corruption recovery) ---------- */
function load() {
  try {
    const d = JSON.parse(localStorage.getItem(KEY));
    if (d && Array.isArray(d.items) && Array.isArray(d.log)) return d;
  } catch (e) { /* fall through to clean template */ }
  return { items: [], log: [], nextId: 1 };
}
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(db)); }
  catch (e) { toast("Could not save: browser storage is full or blocked."); }
}
function toast(msg) {
  const t = $("toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove("show"), 2600);
}

/* ---------- Validation ---------- */
function validateItem(r) {
  const errs = [];
  const name = (r.name || "").trim(), donor = (r.donor || "").trim();
  const qty = Number(r.qty);
  if (name.length < 2 || name.length > 60) errs.push("Item name must be 2–60 characters.");
  if (!CATEGORIES.includes(r.category)) errs.push("Choose a category from the list.");
  if (r.qty === "" || !Number.isInteger(qty) || qty < 1 || qty > MAX_QTY) errs.push(`Quantity must be a whole number from 1 to ${MAX_QTY}.`);
  if (donor.length < 2) errs.push("Donor name is required.");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(r.date || "") || isNaN(new Date(r.date))) errs.push("Date received must be a valid date.");
  else if (r.date > today()) errs.push("Date received cannot be in the future.");
  if (r.expiry) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(r.expiry) || isNaN(new Date(r.expiry))) errs.push("Expiry date is not valid.");
    else if (r.date && r.expiry < r.date) errs.push("Expiry date cannot be before the date received.");
  }
  return errs;
}
function addItem(r) {
  db.items.push({ id: db.nextId++, name: r.name.trim(), category: r.category, received: Number(r.qty),
    stock: Number(r.qty), donor: r.donor.trim(), date: r.date, expiry: r.expiry || "" });
}

/* ---------- Business logic ---------- */
function status(it) {
  if (it.expiry && it.expiry < today() && it.stock > 0) return "Expired";
  if (it.stock === 0) return "Out of stock";
  if (it.stock <= LOW_LIMIT) return "Low stock";
  if (it.expiry) {
    const days = (new Date(it.expiry) - new Date(today())) / 864e5;
    if (days <= SOON_DAYS) return "Expiring soon";
  }
  return "In stock";
}
function distribute(id, qty, to, date) {
  const it = db.items.find(i => i.id === id);
  const errs = [];
  if (!it) errs.push("Pick an item.");
  if (!Number.isInteger(qty) || qty < 1) errs.push("Quantity must be a whole number of at least 1.");
  else if (it && qty > it.stock) errs.push(`Only ${it.stock} in stock for ${it.name}.`);
  if (to.trim().length < 2) errs.push("Recipient is required.");
  if (!date || date > today()) errs.push("Distribution date cannot be empty or in the future.");
  else if (it && date < it.date) errs.push("Distribution date cannot be before the item was received.");
  if (errs.length) return errs;
  it.stock -= qty;
  db.log.unshift({ date, itemId: id, item: it.name, qty, to: to.trim() });
  return [];
}
function stats() {
  const items = db.items;
  const received = items.reduce((s, i) => s + i.received, 0);
  const stock = items.reduce((s, i) => s + i.stock, 0);
  const given = received - stock;
  const donors = {};
  items.forEach(i => donors[i.donor] = (donors[i.donor] || 0) + i.received);
  const top = Object.entries(donors).sort((a, b) => b[1] - a[1])[0];
  const count = s => items.filter(i => status(i) === s).length;
  const cats = CATEGORIES.map(c => {
    const l = items.filter(i => i.category === c);
    const r = l.reduce((s, i) => s + i.received, 0), st = l.reduce((s, i) => s + i.stock, 0);
    return { c, lines: l.length, r, given: r - st, st };
  });
  return { lines: items.length, received, stock, given, avg: items.length ? received / items.length : 0,
    rate: received ? given / received * 100 : 0, top, low: count("Low stock"), out: count("Out of stock"),
    soon: count("Expiring soon"), expired: count("Expired"), cats };
}

/* ---------- Rendering ---------- */
function fillSelects() {
  const opts = CATEGORIES.map(c => `<option>${c}</option>`).join("");
  $("category").innerHTML = `<option value="">Select...</option>` + opts;
  $("filterCat").innerHTML = `<option value="">All categories</option>` + opts;
}
function filtered() {
  const q = $("search").value.trim().toLowerCase(), c = $("filterCat").value, s = $("filterStatus").value;
  return db.items.filter(i => (!q || i.name.toLowerCase().includes(q) || i.donor.toLowerCase().includes(q))
    && (!c || i.category === c) && (!s || status(i) === s));
}
function renderInventory() {
  const list = filtered(), pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  page = Math.min(page, pages);
  const slice = list.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  $("rows").innerHTML = slice.length ? slice.map(i => {
    const s = status(i);
    return `<tr><td>${esc(i.name)}</td><td>${i.category}</td><td class="num">${i.stock} / ${i.received}</td>
      <td>${i.date}</td><td>${esc(i.donor)}</td><td><span class="tag ${s.replace(/ /g, "-")}">${s}</span></td>
      <td><button data-del="${i.id}" aria-label="Delete ${esc(i.name)}">Delete</button></td></tr>`;
  }).join("") : `<tr><td colspan="7">No records match. Add a donation or load the sample data from Import / Export.</td></tr>`;
  $("pageInfo").textContent = `Page ${page} of ${pages} (${list.length} records)`;
  $("prev").disabled = page <= 1; $("next").disabled = page >= pages;
}
function renderDistribute() {
  const avail = db.items.filter(i => i.stock > 0);
  $("dItem").innerHTML = avail.length ? avail.map(i => `<option value="${i.id}">${esc(i.name)} (${i.stock} left)</option>`).join("")
    : `<option value="">Nothing in stock</option>`;
  $("distRows").innerHTML = db.log.length ? db.log.map(l =>
    `<tr><td>${l.date}</td><td>${esc(l.item)}</td><td class="num">${l.qty}</td><td>${esc(l.to)}</td></tr>`).join("")
    : `<tr><td colspan="4">No distributions yet.</td></tr>`;
}
function renderSummary() {
  const s = stats(), a = [];
  if (s.expired) a.push(`<div class="alert bad">${s.expired} item line(s) are expired and still in stock.</div>`);
  if (s.out) a.push(`<div class="alert bad">${s.out} item line(s) are out of stock.</div>`);
  if (s.low) a.push(`<div class="alert warn">${s.low} item line(s) are low (${LOW_LIMIT} or fewer left).</div>`);
  if (s.soon) a.push(`<div class="alert warn">${s.soon} item line(s) expire within ${SOON_DAYS} days.</div>`);
  $("alerts").innerHTML = a.join("") || `<div class="alert ok">No warnings. Stock levels look healthy.</div>`;
  const num = (v, dec = 0, suf = "") => `<span class="count" data-to="${v}" data-dec="${dec}" data-suf="${suf}">0</span>`;
  const card = (v, l) => `<div class="stat"><b>${v}</b><span>${l}</span></div>`;
  $("stats").innerHTML = card(num(s.lines), "Item lines") + card(num(s.received), "Units received") +
    card(num(s.given), "Units given out") + card(num(s.stock), "Units in stock") +
    card(num(s.avg, 1), "Average units per line") + card(num(s.rate, 1, "%"), "Distribution rate") +
    card(s.top ? esc(s.top[0]) : "–", s.top ? `Top donor (${s.top[1]} units)` : "Top donor");
  animateCounts();
  $("catRows").innerHTML = s.cats.map(c => {
    const share = s.stock ? c.st / s.stock * 100 : 0;
    return `<tr><td>${c.c}</td><td class="num">${c.lines}</td><td class="num">${c.r}</td><td class="num">${c.given}</td>
      <td class="num">${c.st}</td><td><div class="bar" title="${share.toFixed(1)}%"><i style="width:${share}%"></i></div></td></tr>`;
  }).join("");
}
function renderAll() { renderInventory(); renderDistribute(); renderSummary(); }

function animateCounts() {
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  document.querySelectorAll(".count").forEach(el => {
    const to = Number(el.dataset.to), dec = Number(el.dataset.dec), suf = el.dataset.suf;
    const fmt = v => v.toFixed(dec) + suf;
    if (reduce || !to) { el.textContent = fmt(to); return; }
    const t0 = performance.now(), dur = 900;
    (function step(t) {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(to * e);
      if (p < 1) requestAnimationFrame(step);
    })(t0);
  });
}

/* ---------- Events ---------- */
$("tabs").addEventListener("click", e => {
  const t = e.target.dataset.tab; if (!t) return;
  document.querySelectorAll("nav button").forEach(b => b.classList.toggle("active", b === e.target));
  document.querySelectorAll(".panel").forEach(p => p.classList.toggle("active", p.id === t));
  renderAll();
});
$("addForm").addEventListener("submit", e => {
  e.preventDefault();
  const r = { name: $("name").value, category: $("category").value, qty: $("qty").value,
    donor: $("donor").value, date: $("received").value, expiry: $("expiry").value };
  const errs = validateItem(r);
  $("addErr").innerHTML = errs.map(esc).join("<br>");
  if (errs.length) return;
  addItem(r); save(); e.target.reset(); $("received").value = today(); renderAll(); toast("Donation added.");
});
$("distForm").addEventListener("submit", e => {
  e.preventDefault();
  const errs = distribute(Number($("dItem").value), Number($("dQty").value), $("dTo").value, $("dDate").value);
  $("distErr").innerHTML = errs.map(esc).join("<br>");
  if (errs.length) return;
  save(); $("dQty").value = ""; $("dTo").value = ""; renderAll(); toast("Distribution recorded.");
});
["search", "filterCat", "filterStatus"].forEach(id => $(id).addEventListener("input", () => { page = 1; renderInventory(); }));
$("prev").onclick = () => { page--; renderInventory(); };
$("next").onclick = () => { page++; renderInventory(); };
$("rows").addEventListener("click", e => {
  const id = Number(e.target.dataset.del); if (!id) return;
  if (confirm("Delete this item line? Its distribution history is kept in the log.")) {
    db.items = db.items.filter(i => i.id !== id); save(); renderAll();
  }
});

/* ---------- Export ---------- */
function download(name, text, type) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 500);
}
const csvCell = v => { v = String(v); if (/^[=+\-@]/.test(v)) v = "'" + v; return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
$("expCsv").onclick = () => {
  const rows = [["name", "category", "quantity", "in_stock", "donor", "date", "expiry", "status"]]
    .concat(db.items.map(i => [i.name, i.category, i.received, i.stock, i.donor, i.date, i.expiry, status(i)]));
  download("inventory.csv", rows.map(r => r.map(csvCell).join(",")).join("\n"), "text/csv");
};
$("expJson").onclick = () => download("donation-backup.json", JSON.stringify(db, null, 2), "application/json");
$("expMd").onclick = () => {
  const s = stats();
  let md = `# Donation Inventory Summary\n\nGenerated ${today()}\n\n- Item lines: ${s.lines}\n- Units received: ${s.received}\n- Units given out: ${s.given}\n- Units in stock: ${s.stock}\n- Average units per line: ${s.avg.toFixed(1)}\n- Distribution rate: ${s.rate.toFixed(1)}%\n- Low stock: ${s.low}, out of stock: ${s.out}, expiring soon: ${s.soon}, expired: ${s.expired}\n\n| Category | Lines | Received | Given | In stock |\n|---|---|---|---|---|\n`;
  s.cats.forEach(c => md += `| ${c.c} | ${c.lines} | ${c.r} | ${c.given} | ${c.st} |\n`);
  download("summary.md", md, "text/markdown");
};
$("expTxt").onclick = () => {
  const lines = [`AUDIT LOG ${today()}`, "", "DONATIONS"].concat(db.items.map(i => `${i.date} | ${i.name} | ${i.received} units | donor: ${i.donor} | ${status(i)}`),
    ["", "DISTRIBUTIONS"], db.log.map(l => `${l.date} | ${l.item} | ${l.qty} units | to: ${l.to}`));
  download("audit-log.txt", lines.join("\n"), "text/plain");
};

/* ---------- Import ---------- */
function parseCSV(text) {
  const rows = []; let row = [], cell = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === ",") { row.push(cell); cell = ""; }
    else if (c === "\n" || c === "\r") { if (c === "\r" && text[i + 1] === "\n") i++; row.push(cell); rows.push(row); row = []; cell = ""; }
    else cell += c;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows.filter(r => r.some(x => x.trim()));
}
$("file").addEventListener("change", e => {
  const f = e.target.files[0]; if (!f) return;
  const rd = new FileReader();
  rd.onload = () => {
    const rows = parseCSV(String(rd.result)), log = [];
    const head = (rows.shift() || []).map(h => h.trim().toLowerCase());
    const need = ["name", "category", "quantity", "donor", "date"];
    const miss = need.filter(h => !head.includes(h));
    if (miss.length) { $("importLog").textContent = "Import stopped. Missing column(s): " + miss.join(", "); return; }
    let ok = 0;
    rows.forEach((r, n) => {
      const o = {}; head.forEach((h, i) => o[h] = (r[i] || "").trim());
      const rec = { name: o.name, category: o.category, qty: o.quantity, donor: o.donor, date: o.date, expiry: o.expiry };
      const errs = validateItem(rec);
      if (errs.length) log.push(`Row ${n + 2}: skipped. ${errs.join(" ")}`); else { addItem(rec); ok++; }
    });
    save(); renderAll(); e.target.value = "";
    $("importLog").textContent = `Imported ${ok} row(s). Skipped ${log.length}.\n` + log.join("\n");
  };
  rd.readAsText(f);
});

/* ---------- Sample data ---------- */
$("seed").onclick = () => {
  const names = { Food: ["Rice sacks", "Canned beans", "Cooking oil", "Lentils"], Clothing: ["Winter jackets", "School uniforms", "Blankets", "Socks"],
    Medical: ["First-aid kits", "Face masks", "Paracetamol strips", "Bandages"], Books: ["Textbooks", "Story books", "Notebooks", "Dictionaries"],
    Toys: ["Board games", "Soft toys", "Building blocks", "Puzzles"], Hygiene: ["Soap bars", "Toothpaste", "Sanitary pads", "Shampoo"],
    Electronics: ["Calculators", "Torches", "Phone chargers", "Radios"], Household: ["Steel plates", "Buckets", "Mats", "Water filters"] };
  const donors = ["Green Valley School", "Asha Foundation", "R. Kumar", "City Rotary Club", "Lions Club", "Anonymous donor", "Sunrise Bakery", "Tech Club"];
  const day = n => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
  const qtys = [250, 40, 12, 8, 500, 3, 100000, 1, 75, 60];
  for (let i = 0; i < 40; i++) {
    const c = CATEGORIES[i % 8], n = names[c][Math.floor(i / 8) % 4];
    const perishable = c === "Food" || c === "Medical";
    addItem({ name: n, category: c, qty: qtys[i % qtys.length], donor: donors[(i * 3) % donors.length], date: day(-(5 + i * 3)),
      expiry: perishable ? day(i % 5 === 0 ? -(i + 2) + 3 : (i % 3 === 0 ? 15 : 200)) : "" });
  }
  // a few distributions, one that empties an item (edge case)
  db.items.slice(0, 6).forEach((it, k) => distribute(it.id, k === 3 ? it.stock : Math.ceil(it.stock / 4), "Community shelter", day(-1)));
  save(); renderAll(); toast("Sample data loaded.");
};
$("wipe").onclick = () => {
  if (confirm("Delete all items and distribution history? This cannot be undone.")) {
    db = { items: [], log: [], nextId: 1 }; save(); renderAll(); toast("All data deleted.");
  }
};

/* ---------- Init ---------- */
fillSelects();
$("received").value = today(); $("dDate").value = today();
renderAll();
