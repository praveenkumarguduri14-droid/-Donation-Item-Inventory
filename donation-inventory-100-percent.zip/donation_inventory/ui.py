"""Terminal presentation, ANSI color formatting, and table layout."""

from __future__ import annotations

import sys
from typing import Any, Callable, Optional

# ANSI Color Codes
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"

BG_RED = "\033[41m"
BG_GREEN = "\033[42m"
BG_YELLOW = "\033[43m"
BG_BLUE = "\033[44m"


def supports_color() -> bool:
    """Detect if stdout supports ANSI colors."""
    return sys.stdout.isatty()


def colorize(text: str, color_code: str) -> str:
    if not supports_color():
        return text
    return f"{color_code}{text}{RESET}"


def status_badge(status: str) -> str:
    """Returns a styled, color-coded badge for an item status."""
    st = status.strip()
    if st == "In stock":
        return colorize(f" [ IN STOCK ] ", GREEN)
    elif st == "Low stock":
        return colorize(f" [ LOW STOCK ] ", YELLOW)
    elif st == "Expiring soon":
        return colorize(f" [ EXPIRING SOON ] ", YELLOW)
    elif st == "Out of stock":
        return colorize(f" [ OUT OF STOCK ] ", RED)
    elif st == "Expired":
        return colorize(f" [ EXPIRED ] ", RED)
    return f" [ {st} ] "


def print_banner() -> None:
    """Prints a styled CLI application banner."""
    title = """
========================================================================
           DONATION ITEM INVENTORY & DISTRIBUTION SYSTEM (v2.0)
     Enterprise Python 3.10+ CLI | SQLite Relational Backend
========================================================================
"""
    print(colorize(title, CYAN + BOLD))


def print_table(headers: list[str], rows: list[list[Any]], alignments: Optional[list[str]] = None) -> None:
    """Renders an ASCII/ANSI formatted table with dynamic column sizing."""
    if not headers:
        return

    # Convert all items to string representations
    str_rows: list[list[str]] = []
    for r in rows:
        str_rows.append([str(c) if c is not None else "" for c in r])

    # Compute maximum width per column
    col_widths = [len(h) for h in headers]
    for r in str_rows:
        for idx, val in enumerate(r):
            # strip ansi codes for width calculation if any
            clean_len = len(val.replace("\033[0m", "").replace("\033[1m", "").replace("\033[31m", "")
                            .replace("\033[32m", "").replace("\033[33m", "").replace("\033[34m", "")
                            .replace("\033[35m", "").replace("\033[36m", "").replace("\033[37m", ""))
            if clean_len > col_widths[idx]:
                col_widths[idx] = clean_len

    aligns = alignments or ["left"] * len(headers)

    # Formatters
    def fmt_cell(val: str, width: int, align: str) -> str:
        clean_len = len(val.replace("\033[0m", "").replace("\033[1m", "").replace("\033[31m", "")
                        .replace("\033[32m", "").replace("\033[33m", "").replace("\033[34m", "")
                        .replace("\033[35m", "").replace("\033[36m", "").replace("\033[37m", ""))
        padding = " " * max(0, width - clean_len)
        return (padding + val) if align == "right" else (val + padding)

    # Separator
    border = "+-" + "-+-".join("-" * w for w in col_widths) + "-+"

    print(border)
    header_line = "| " + " | ".join(fmt_cell(colorize(h, BOLD + WHITE), col_widths[i], aligns[i]) for i, h in enumerate(headers)) + " |"
    print(header_line)
    print(border)

    if not str_rows:
        empty_msg = "(No records to display)"
        print(f"| {empty_msg.center(len(border) - 4)} |")
    else:
        for r in str_rows:
            row_line = "| " + " | ".join(fmt_cell(r[i], col_widths[i], aligns[i]) for i in range(len(headers))) + " |"
            print(row_line)

    print(border)


def print_success(message: str) -> None:
    print(colorize(f"SUCCESS: {message}", GREEN + BOLD))


def print_error(message: str) -> None:
    print(colorize(f"ERROR: {message}", RED + BOLD))


def print_warning(message: str) -> None:
    print(colorize(f"WARNING: {message}", YELLOW + BOLD))


def print_info(message: str) -> None:
    print(colorize(f"INFO: {message}", CYAN))


def prompt_string(prompt_text: str, default: Optional[str] = None, allow_empty: bool = False) -> str:
    """Interactively prompts user for string input."""
    suffix = f" [{default}]" if default else ""
    while True:
        try:
            val = input(colorize(f"{prompt_text}{suffix}: ", BOLD)).strip()
        except (KeyboardInterrupt, EOFError):
            print("\nAborted.")
            sys.exit(0)
        if not val and default is not None:
            return default
        if not val and not allow_empty:
            print_error("Input cannot be empty. Please try again.")
            continue
        return val


def confirm_prompt(prompt_text: str, default: bool = False) -> bool:
    """Asks for confirmation (y/n)."""
    options = "[y/N]" if not default else "[Y/n]"
    try:
        val = input(colorize(f"{prompt_text} {options}: ", YELLOW + BOLD)).strip().lower()
    except (KeyboardInterrupt, EOFError):
        print("\nAborted.")
        sys.exit(0)
    if not val:
        return default
    return val in ("y", "yes")
