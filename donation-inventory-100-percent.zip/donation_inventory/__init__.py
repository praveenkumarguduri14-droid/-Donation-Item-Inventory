"""Donation Item Inventory Management System.

A robust Python 3.10+ CLI application with SQLite persistence,
modular clean architecture, and comprehensive automated tests.
"""

__version__ = "2.0.0"
__author__ = "mrv_ece_gp12 (MRVECE2630012)"
