"""Business logic and service orchestration layer."""

from __future__ import annotations

import csv
from datetime import date, datetime, timedelta
import json
from pathlib import Path
from typing import Any, Optional

from donation_inventory.database import (
    DatabaseManager,
    DistributionRepository,
    ItemRepository,
)
from donation_inventory.models import (
    Category,
    CategorySummary,
    Distribution,
    InventoryStats,
    Item,
    ItemStatus,
)
from donation_inventory.validators import (
    NotFoundError,
    ValidationError,
    sanitize_formula_injection,
    validate_distribution_data,
    validate_item_data,
)


class InventoryService:
    """Core domain service for inventory operations, distributions, reporting, and imports/exports."""

    def __init__(self, db_manager: Optional[DatabaseManager] = None):
        self.db = db_manager or DatabaseManager()
        self.items_repo = ItemRepository(self.db)
        self.dist_repo = DistributionRepository(self.db)

    # ------------------ Item Operations ------------------

    def add_item(
        self,
        name: str,
        category: str,
        quantity: int | str,
        donor: str,
        date_received: str,
        expiry_date: Optional[str] = None,
        current_date: Optional[date] = None,
    ) -> Item:
        """Validates and records a new donation item."""
        errors = validate_item_data(
            name=name,
            category=category,
            quantity=quantity,
            donor=donor,
            date_received=date_received,
            expiry_date=expiry_date,
            current_date=current_date,
        )
        if errors:
            raise ValidationError(errors)

        # Standardize category case
        matched_cat = Category.from_str(category).value
        item = Item(
            id=None,
            name=name.strip(),
            category=matched_cat,
            received=int(quantity),
            stock=int(quantity),
            donor=donor.strip(),
            date_received=date_received.strip(),
            expiry_date=expiry_date.strip() if expiry_date and expiry_date.strip() else None,
        )
        return self.items_repo.create(item)

    def get_item(self, item_id: int) -> Item:
        """Retrieves a single item or raises NotFoundError."""
        item = self.items_repo.get_by_id(item_id)
        if not item:
            raise NotFoundError(f"Item with ID {item_id} not found.")
        return item

    def delete_item(self, item_id: int) -> bool:
        """Deletes an item line (and cascades associated distributions)."""
        if not self.items_repo.get_by_id(item_id):
            raise NotFoundError(f"Item with ID {item_id} not found.")
        return self.items_repo.delete(item_id)

    def list_items(
        self,
        search: Optional[str] = None,
        category: Optional[str] = None,
        status: Optional[str] = None,
        page: int = 1,
        page_size: int = 10,
        current_date: Optional[date] = None,
    ) -> tuple[list[Item], int]:
        """Lists items with multi-criteria filtering, search, and pagination."""
        all_items = self.items_repo.get_all()
        ref_date = current_date or date.today()

        filtered: list[Item] = []
        q = (search or "").strip().lower()
        cat_filter = (category or "").strip().lower()
        stat_filter = (status or "").strip().lower()

        for item in all_items:
            # Search filter (name or donor)
            if q and (q not in item.name.lower() and q not in item.donor.lower()):
                continue
            # Category filter
            if cat_filter and item.category.lower() != cat_filter:
                continue
            # Status filter
            if stat_filter and item.calculate_status(ref_date).value.lower() != stat_filter:
                continue
            filtered.append(item)

        total_records = len(filtered)
        if page < 1:
            page = 1
        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size

        return filtered[start_idx:end_idx], total_records

    # ------------------ Distribution Operations ------------------

    def record_distribution(
        self,
        item_id: int,
        quantity: int | str,
        recipient: str,
        date_given: str,
        current_date: Optional[date] = None,
    ) -> Distribution:
        """Validates and atomically records a distribution, deducting stock."""
        item = self.items_repo.get_by_id(item_id)
        errors = validate_distribution_data(
            item=item,
            quantity=quantity,
            recipient=recipient,
            date_given=date_given,
            current_date=current_date,
        )
        if errors:
            raise ValidationError(errors)

        assert item is not None
        qty_int = int(quantity)

        # Atomic transaction: decrement stock and insert audit record
        with self.db.transaction() as conn:
            new_stock = item.stock - qty_int
            self.items_repo.update_stock(item_id, new_stock, conn=conn)
            dist = Distribution(
                id=None,
                item_id=item.id or item_id,
                item_name=item.name,
                quantity=qty_int,
                recipient=recipient.strip(),
                date_given=date_given.strip(),
            )
            return self.dist_repo.create(dist, conn=conn)

    def list_distributions(self, limit: Optional[int] = None) -> list[Distribution]:
        """Retrieves distribution log history."""
        return self.dist_repo.get_all(limit=limit)

    # ------------------ Statistics & Analytics ------------------

    def get_stats(self, current_date: Optional[date] = None) -> InventoryStats:
        """Calculates comprehensive aggregate analytics and category breakdowns."""
        items = self.items_repo.get_all()
        ref_date = current_date or date.today()

        total_lines = len(items)
        units_received = sum(i.received for i in items)
        units_in_stock = sum(i.stock for i in items)
        units_given_out = units_received - units_in_stock

        avg_units = (units_received / total_lines) if total_lines > 0 else 0.0
        dist_rate = (units_given_out / units_received * 100.0) if units_received > 0 else 0.0

        # Donor rankings
        donor_tallies: dict[str, int] = {}
        for item in items:
            donor_tallies[item.donor] = donor_tallies.get(item.donor, 0) + item.received
        sorted_donors = sorted(donor_tallies.items(), key=lambda kv: kv[1], reverse=True)
        top_donor = sorted_donors[0] if sorted_donors else None

        # Status counts
        status_counts = {
            ItemStatus.EXPIRED: 0,
            ItemStatus.OUT_OF_STOCK: 0,
            ItemStatus.LOW_STOCK: 0,
            ItemStatus.EXPIRING_SOON: 0,
            ItemStatus.IN_STOCK: 0,
        }
        for item in items:
            st = item.calculate_status(ref_date)
            status_counts[st] += 1

        # Category summaries
        cat_summaries: list[CategorySummary] = []
        for cat_name in Category.list():
            cat_items = [i for i in items if i.category == cat_name]
            lines = len(cat_items)
            rcv = sum(i.received for i in cat_items)
            stk = sum(i.stock for i in cat_items)
            gvn = rcv - stk
            share_pct = (stk / units_in_stock * 100.0) if units_in_stock > 0 else 0.0
            cat_summaries.append(
                CategorySummary(
                    category=cat_name,
                    lines=lines,
                    received=rcv,
                    given=gvn,
                    in_stock=stk,
                    share_of_stock_pct=round(share_pct, 1),
                )
            )

        return InventoryStats(
            total_lines=total_lines,
            units_received=units_received,
            units_in_stock=units_in_stock,
            units_given_out=units_given_out,
            avg_units_per_line=round(avg_units, 1),
            distribution_rate_pct=round(dist_rate, 1),
            top_donor=top_donor,
            count_low_stock=status_counts[ItemStatus.LOW_STOCK],
            count_out_of_stock=status_counts[ItemStatus.OUT_OF_STOCK],
            count_expiring_soon=status_counts[ItemStatus.EXPIRING_SOON],
            count_expired=status_counts[ItemStatus.EXPIRED],
            category_summaries=cat_summaries,
        )

    # ------------------ Import & Export ------------------

    def export_csv(self, filepath: str | Path) -> str:
        """Exports inventory rows to CSV with formula injection sanitization."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        items = self.items_repo.get_all()

        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["id", "name", "category", "quantity", "in_stock", "donor", "date", "expiry", "status"])
            for item in items:
                writer.writerow([
                    item.id,
                    sanitize_formula_injection(item.name),
                    item.category,
                    item.received,
                    item.stock,
                    sanitize_formula_injection(item.donor),
                    item.date_received,
                    item.expiry_date or "",
                    item.status,
                ])
        return str(path.resolve())

    def export_json(self, filepath: str | Path) -> str:
        """Exports full database snapshot to JSON."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        items = [i.to_dict() for i in self.items_repo.get_all()]
        dists = [d.to_dict() for d in self.dist_repo.get_all()]

        data = {
            "version": "2.0.0",
            "exported_at": datetime.now().isoformat(),
            "items": items,
            "distributions": dists,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return str(path.resolve())

    def export_markdown(self, filepath: str | Path) -> str:
        """Generates an executive Markdown summary report."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        stats = self.get_stats()
        today_str = date.today().isoformat()

        top_donor_str = f"{stats.top_donor[0]} ({stats.top_donor[1]:,} units)" if stats.top_donor else "None"

        lines = [
            "# Donation Item Inventory Summary Report",
            f"\n*Generated on: {today_str}*\n",
            "## Executive Overview",
            f"- **Item Lines:** {stats.total_lines}",
            f"- **Total Units Received:** {stats.units_received:,}",
            f"- **Total Units Given Out:** {stats.units_given_out:,}",
            f"- **Total Units In Stock:** {stats.units_in_stock:,}",
            f"- **Average Units per Line:** {stats.avg_units_per_line}",
            f"- **Distribution Rate:** {stats.distribution_rate_pct}%",
            f"- **Top Donor:** {top_donor_str}",
            f"- **Stock Alerts:** {stats.count_expired} expired | {stats.count_out_of_stock} out of stock | {stats.count_low_stock} low stock | {stats.count_expiring_soon} expiring soon",
            "\n## Category Breakdown",
            "| Category | Lines | Received | Given Out | In Stock | Share of Stock |",
            "|:---|---:|---:|---:|---:|---:|",
        ]
        for cat in stats.category_summaries:
            lines.append(
                f"| {cat.category} | {cat.lines} | {cat.received:,} | {cat.given:,} | {cat.in_stock:,} | {cat.share_of_stock_pct}% |"
            )

        content = "\n".join(lines) + "\n"
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return str(path.resolve())

    def export_audit_log(self, filepath: str | Path) -> str:
        """Exports human-readable audit trail of all donations and distributions."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        today_str = date.today().isoformat()
        items = self.items_repo.get_all()
        dists = self.dist_repo.get_all()

        lines = [
            f"=== DONATION INVENTORY AUDIT LOG ({today_str}) ===",
            "\n[1] DONATIONS RECEIVED:",
        ]
        for it in items:
            lines.append(
                f"  {it.date_received} | ID #{it.id:04d} | {it.name} ({it.category}) | {it.received} units | Donor: {it.donor} | Status: {it.status}"
            )
        lines.append("\n[2] DISTRIBUTIONS GIVEN OUT:")
        if not dists:
            lines.append("  (No distributions recorded yet)")
        for d in dists:
            lines.append(
                f"  {d.date_given} | Dist ID #{d.id:04d} | {d.item_name} (Item #{d.item_id}) | {d.quantity} units | Recipient: {d.recipient}"
            )

        content = "\n".join(lines) + "\n"
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return str(path.resolve())

    def import_csv(self, filepath: str | Path) -> tuple[int, list[str]]:
        """Imports donation items from a CSV file with robust column mapping and error logging."""
        path = Path(filepath)
        if not path.is_file():
            raise FileNotFoundError(f"File not found: {filepath}")

        imported_count = 0
        error_log: list[str] = []

        with open(path, "r", encoding="utf-8-sig") as f:
            reader = csv.reader(f)
            header_row = next(reader, None)
            if not header_row:
                raise ValidationError(["CSV file is empty."])

            col_map: dict[str, int] = {col.strip().lower(): idx for idx, col in enumerate(header_row)}
            required = ["name", "category", "quantity", "donor", "date"]
            missing = [r for r in required if r not in col_map]
            if missing:
                raise ValidationError([f"CSV missing mandatory column(s): {', '.join(missing)}"])

            for row_num, row in enumerate(reader, start=2):
                if not any(cell.strip() for cell in row):
                    continue  # skip blank lines

                def get_val(key: str) -> str:
                    idx = col_map.get(key)
                    if idx is not None and idx < len(row):
                        return row[idx].strip()
                    return ""

                name = get_val("name")
                category = get_val("category")
                qty = get_val("quantity")
                donor = get_val("donor")
                date_rcv = get_val("date")
                expiry = get_val("expiry") or None

                errs = validate_item_data(name, category, qty, donor, date_rcv, expiry)
                if errs:
                    error_log.append(f"Row {row_num}: Skipped. {'; '.join(errs)}")
                else:
                    try:
                        self.add_item(name, category, qty, donor, date_rcv, expiry)
                        imported_count += 1
                    except Exception as ex:
                        error_log.append(f"Row {row_num}: Error saving. {str(ex)}")

        return imported_count, error_log

    # ------------------ Sample Data & Wipe ------------------

    def seed_sample_data(self) -> int:
        """Seeds 40 realistic sample records covering all 8 categories and edge cases."""
        sample_names = {
            "Food": ["Rice sacks", "Canned beans", "Cooking oil", "Lentils", "Flour bags"],
            "Clothing": ["Winter jackets", "School uniforms", "Blankets", "Thermal socks", "Raincoats"],
            "Medical": ["First-aid kits", "Face masks", "Paracetamol strips", "Bandages", "Antiseptic bottles"],
            "Books": ["Textbooks", "Story books", "Notebooks", "Dictionaries", "Drawing books"],
            "Toys": ["Board games", "Soft toys", "Building blocks", "Puzzles", "Action figures"],
            "Hygiene": ["Soap bars", "Toothpaste", "Sanitary pads", "Shampoo bottles", "Hand sanitizers"],
            "Electronics": ["Calculators", "Solar lanterns", "Phone chargers", "Radios", "Table lamps"],
            "Household": ["Steel plates", "Plastic buckets", "Floor mats", "Water filters", "Cooking pots"],
        }
        donors = [
            "Green Valley School", "Asha Foundation", "R. Kumar", "City Rotary Club",
            "Lions Club International", "Anonymous Donor", "Sunrise Bakery", "Tech Care Guild",
        ]
        qtys = [250, 40, 12, 8, 500, 3, 1000, 1, 75, 60]

        now = date.today()
        categories = Category.list()
        created_items: list[Item] = []

        for i in range(40):
            cat = categories[i % len(categories)]
            name_candidates = sample_names[cat]
            name = name_candidates[(i // len(categories)) % len(name_candidates)]
            qty = qtys[i % len(qtys)]
            donor = donors[(i * 3) % len(donors)]
            date_rcv = (now - timedelta(days=5 + i * 3)).isoformat()

            expiry: Optional[str] = None
            if cat in ("Food", "Medical"):
                if i % 5 == 0:
                    # Expired
                    expiry = (now - timedelta(days=abs((i + 2) - 3) + 1)).isoformat()
                elif i % 3 == 0:
                    # Expiring soon (within 15 days)
                    expiry = (now + timedelta(days=15)).isoformat()
                else:
                    # Safe future
                    expiry = (now + timedelta(days=200)).isoformat()

            item = self.add_item(name, cat, qty, donor, date_rcv, expiry)
            created_items.append(item)

        # Create realistic distributions (including edge case of depleting an item to 0)
        dist_recipients = [
            "Community Shelter", "Hope Orphanage", "Red Cross Relief Center",
            "Elder Care Home", "Rural Health Post", "Flood Relief Camp",
        ]
        for k, it in enumerate(created_items[:6]):
            recip = dist_recipients[k % len(dist_recipients)]
            dist_date = (now - timedelta(days=1)).isoformat()
            # If k == 3, distribute ALL remaining stock to trigger exact out-of-stock edge case
            dist_qty = it.stock if k == 3 else max(1, it.stock // 4)
            self.record_distribution(it.id, dist_qty, recip, dist_date)

        return len(created_items)

    def wipe_all_data(self) -> None:
        """Deletes all items and distributions."""
        self.items_repo.clear_all()
