"""Validation logic and domain exception definitions."""

from __future__ import annotations

from datetime import date, datetime
import re
from typing import Optional

from donation_inventory.models import (
    Category,
    Item,
    MAX_QUANTITY,
)


class InventoryError(Exception):
    """Base exception for inventory application."""
    pass


class ValidationError(InventoryError):
    """Raised when user or file inputs fail validation rules."""
    def __init__(self, errors: list[str]):
        super().__init__("; ".join(errors))
        self.errors = errors


class NotFoundError(InventoryError):
    """Raised when a requested resource does not exist."""
    pass


class InsufficientStockError(InventoryError):
    """Raised when attempting to distribute more stock than available."""
    pass


DATE_REGEX = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def parse_date(date_str: str) -> Optional[date]:
    """Parses a YYYY-MM-DD string into a date object, returning None if invalid."""
    if not date_str or not DATE_REGEX.match(date_str.strip()):
        return None
    try:
        return datetime.strptime(date_str.strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def sanitize_formula_injection(value: str) -> str:
    """Neutralize spreadsheet/CSV formula injection risks (=, +, -, @, \\t, \\r)."""
    if not value:
        return ""
    val_str = str(value)
    if val_str and val_str[0] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + val_str
    return val_str


def validate_item_data(
    name: str,
    category: str,
    quantity: int | str,
    donor: str,
    date_received: str,
    expiry_date: Optional[str] = None,
    current_date: Optional[date] = None,
) -> list[str]:
    """Validates item input according to SRS specifications."""
    errors: list[str] = []
    ref_date = current_date or date.today()

    clean_name = (name or "").strip()
    clean_donor = (donor or "").strip()

    if len(clean_name) < 2 or len(clean_name) > 60:
        errors.append("Item name must be between 2 and 60 characters.")

    if not Category.has_value(category):
        errors.append(f"Category must be one of: {', '.join(Category.list())}.")

    try:
        qty_int = int(quantity)
        if qty_int < 1 or qty_int > MAX_QUANTITY:
            errors.append(f"Quantity must be a whole number from 1 to {MAX_QUANTITY:,}.")
    except (ValueError, TypeError):
        errors.append(f"Quantity must be a valid whole number from 1 to {MAX_QUANTITY:,}.")

    if len(clean_donor) < 2 or len(clean_donor) > 60:
        errors.append("Donor name must be between 2 and 60 characters.")

    rcv_date = parse_date(date_received)
    if not rcv_date:
        errors.append("Date received must be a valid date in YYYY-MM-DD format.")
    elif rcv_date > ref_date:
        errors.append("Date received cannot be in the future.")

    if expiry_date and expiry_date.strip():
        exp_date = parse_date(expiry_date)
        if not exp_date:
            errors.append("Expiry date is not valid. Use YYYY-MM-DD format.")
        elif rcv_date and exp_date < rcv_date:
            errors.append("Expiry date cannot be before the date received.")

    return errors


def validate_distribution_data(
    item: Optional[Item],
    quantity: int | str,
    recipient: str,
    date_given: str,
    current_date: Optional[date] = None,
) -> list[str]:
    """Validates distribution input and checks stock constraints."""
    errors: list[str] = []
    ref_date = current_date or date.today()

    if not item:
        errors.append("A valid item must be selected.")
        return errors

    clean_recipient = (recipient or "").strip()
    if len(clean_recipient) < 2 or len(clean_recipient) > 60:
        errors.append("Recipient name must be between 2 and 60 characters.")

    try:
        qty_int = int(quantity)
        if qty_int < 1:
            errors.append("Distribution quantity must be at least 1.")
        elif qty_int > item.stock:
            errors.append(f"Insufficient stock for '{item.name}'. Available: {item.stock}, Requested: {qty_int}.")
    except (ValueError, TypeError):
        errors.append("Distribution quantity must be a positive whole number.")

    dist_date = parse_date(date_given)
    if not dist_date:
        errors.append("Distribution date must be a valid date in YYYY-MM-DD format.")
    else:
        if dist_date > ref_date:
            errors.append("Distribution date cannot be in the future.")
        rcv_date = parse_date(item.date_received)
        if rcv_date and dist_date < rcv_date:
            errors.append("Distribution date cannot be before the item's received date.")

    return errors
