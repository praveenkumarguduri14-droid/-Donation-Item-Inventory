"""Database persistence layer using SQLite.

Provides ACID transactions, relational integrity, foreign keys, and indexing.
Eliminates browser storage limits (5MB) by supporting millions of records.
"""

from __future__ import annotations

from contextlib import contextmanager
import sqlite3
from typing import Generator, Optional

from donation_inventory.models import Distribution, Item


SCHEMA_SQL = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    received INTEGER NOT NULL,
    stock INTEGER NOT NULL,
    donor TEXT NOT NULL,
    date_received TEXT NOT NULL,
    expiry_date TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS distributions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id INTEGER NOT NULL,
    item_name TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    recipient TEXT NOT NULL,
    date_given TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items (id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_items_category ON items(category);
CREATE INDEX IF NOT EXISTS idx_items_name ON items(name);
CREATE INDEX IF NOT EXISTS idx_items_donor ON items(donor);
CREATE INDEX IF NOT EXISTS idx_dist_date ON distributions(date_given);
"""


class DatabaseManager:
    """Manages SQLite connections and schema initialization."""

    def __init__(self, db_path: str = "donation_inventory.db"):
        self.db_path = db_path
        self._is_memory = (db_path == ":memory:" or db_path.startswith("file::memory:"))
        self._shared_conn: Optional[sqlite3.Connection] = None

        if self._is_memory:
            # For in-memory databases, keep a persistent connection so tables aren't lost on close
            self._shared_conn = sqlite3.connect(":memory:")
            self._shared_conn.row_factory = sqlite3.Row
            self._shared_conn.execute("PRAGMA foreign_keys = ON;")

        self._initialize()

    def get_connection(self) -> sqlite3.Connection:
        if self._is_memory and self._shared_conn is not None:
            return self._shared_conn

        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    @contextmanager
    def transaction(self) -> Generator[sqlite3.Connection, None, None]:
        """Provides an atomic transaction scope with auto commit/rollback."""
        conn = self.get_connection()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            if not self._is_memory:
                conn.close()

    def _initialize(self) -> None:
        """Initializes tables and indexes."""
        with self.transaction() as conn:
            conn.executescript(SCHEMA_SQL)

    def close(self) -> None:
        if self._shared_conn:
            self._shared_conn.close()
            self._shared_conn = None


class ItemRepository:
    """Data access repository for Item entities."""

    def __init__(self, db: DatabaseManager):
        self.db = db

    def create(self, item: Item) -> Item:
        with self.db.transaction() as conn:
            cursor = conn.execute(
                """
                INSERT INTO items (name, category, received, stock, donor, date_received, expiry_date)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (item.name, item.category, item.received, item.stock, item.donor, item.date_received, item.expiry_date),
            )
            item.id = cursor.lastrowid
            return item

    def get_by_id(self, item_id: int) -> Optional[Item]:
        with self.db.transaction() as conn:
            row = conn.execute(
                "SELECT id, name, category, received, stock, donor, date_received, expiry_date FROM items WHERE id = ?",
                (item_id,),
            ).fetchone()
            if not row:
                return None
            return Item(
                id=row["id"],
                name=row["name"],
                category=row["category"],
                received=row["received"],
                stock=row["stock"],
                donor=row["donor"],
                date_received=row["date_received"],
                expiry_date=row["expiry_date"],
            )

    def get_all(self) -> list[Item]:
        with self.db.transaction() as conn:
            rows = conn.execute(
                "SELECT id, name, category, received, stock, donor, date_received, expiry_date FROM items ORDER BY id ASC"
            ).fetchall()
            return [
                Item(
                    id=r["id"],
                    name=r["name"],
                    category=r["category"],
                    received=r["received"],
                    stock=r["stock"],
                    donor=r["donor"],
                    date_received=r["date_received"],
                    expiry_date=r["expiry_date"],
                )
                for r in rows
            ]

    def update_stock(self, item_id: int, new_stock: int, conn: Optional[sqlite3.Connection] = None) -> bool:
        sql = "UPDATE items SET stock = ? WHERE id = ?"
        if conn:
            cur = conn.execute(sql, (new_stock, item_id))
            return cur.rowcount > 0
        with self.db.transaction() as c:
            cur = c.execute(sql, (new_stock, item_id))
            return cur.rowcount > 0

    def delete(self, item_id: int) -> bool:
        with self.db.transaction() as conn:
            cur = conn.execute("DELETE FROM items WHERE id = ?", (item_id,))
            return cur.rowcount > 0

    def clear_all(self) -> None:
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM distributions;")
            conn.execute("DELETE FROM items;")


class DistributionRepository:
    """Data access repository for Distribution log entries."""

    def __init__(self, db: DatabaseManager):
        self.db = db

    def create(self, dist: Distribution, conn: Optional[sqlite3.Connection] = None) -> Distribution:
        sql = """
            INSERT INTO distributions (item_id, item_name, quantity, recipient, date_given)
            VALUES (?, ?, ?, ?, ?)
        """
        params = (dist.item_id, dist.item_name, dist.quantity, dist.recipient, dist.date_given)
        if conn:
            cursor = conn.execute(sql, params)
            dist.id = cursor.lastrowid
            return dist
        with self.db.transaction() as c:
            cursor = c.execute(sql, params)
            dist.id = cursor.lastrowid
            return dist

    def get_all(self, limit: Optional[int] = None) -> list[Distribution]:
        sql = "SELECT id, item_id, item_name, quantity, recipient, date_given FROM distributions ORDER BY id DESC"
        if limit:
            sql += f" LIMIT {int(limit)}"
        with self.db.transaction() as conn:
            rows = conn.execute(sql).fetchall()
            return [
                Distribution(
                    id=r["id"],
                    item_id=r["item_id"],
                    item_name=r["item_name"],
                    quantity=r["quantity"],
                    recipient=r["recipient"],
                    date_given=r["date_given"],
                )
                for r in rows
            ]
