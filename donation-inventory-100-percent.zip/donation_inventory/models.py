"""Data models and domain entities for the Donation Item Inventory system."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, datetime
from enum import Enum
from typing import Any, Optional


class Category(str, Enum):
    """Supported donation categories."""
    FOOD = "Food"
    CLOTHING = "Clothing"
    MEDICAL = "Medical"
    BOOKS = "Books"
    TOYS = "Toys"
    HYGIENE = "Hygiene"
    ELECTRONICS = "Electronics"
    HOUSEHOLD = "Household"

    @classmethod
    def list(cls) -> list[str]:
        return [c.value for c in cls]

    @classmethod
    def has_value(cls, val: str) -> bool:
        return any(c.value.lower() == val.lower().strip() for c in cls)

    @classmethod
    def from_str(cls, val: str) -> Category:
        for c in cls:
            if c.value.lower() == val.lower().strip():
                return c
        raise ValueError(f"'{val}' is not a valid Category. Valid options: {cls.list()}")


class ItemStatus(str, Enum):
    """Lifecycle status for inventory items."""
    EXPIRED = "Expired"
    OUT_OF_STOCK = "Out of stock"
    LOW_STOCK = "Low stock"
    EXPIRING_SOON = "Expiring soon"
    IN_STOCK = "In stock"


LOW_STOCK_THRESHOLD: int = 10
EXPIRING_SOON_DAYS: int = 30
MAX_QUANTITY: int = 100_000


@dataclass
class Item:
    """Represents a donated item inventory line."""
    id: Optional[int]
    name: str
    category: str
    received: int
    stock: int
    donor: str
    date_received: str  # YYYY-MM-DD
    expiry_date: Optional[str] = None  # YYYY-MM-DD or None

    def calculate_status(self, current_date: Optional[date] = None) -> ItemStatus:
        """Determines item status based on stock and expiry rules."""
        ref_date = current_date or date.today()

        # 1. Expired: expiry exists, is strictly before today, and stock > 0
        if self.expiry_date:
            try:
                exp_dt = datetime.strptime(self.expiry_date, "%Y-%m-%d").date()
                if exp_dt < ref_date and self.stock > 0:
                    return ItemStatus.EXPIRED
            except ValueError:
                pass

        # 2. Out of stock
        if self.stock <= 0:
            return ItemStatus.OUT_OF_STOCK

        # 3. Low stock (<= 10)
        if self.stock <= LOW_STOCK_THRESHOLD:
            return ItemStatus.LOW_STOCK

        # 4. Expiring soon (within next 30 days)
        if self.expiry_date:
            try:
                exp_dt = datetime.strptime(self.expiry_date, "%Y-%m-%d").date()
                delta_days = (exp_dt - ref_date).days
                if 0 <= delta_days <= EXPIRING_SOON_DAYS:
                    return ItemStatus.EXPIRING_SOON
            except ValueError:
                pass

        # 5. Normal in-stock
        return ItemStatus.IN_STOCK

    @property
    def status(self) -> str:
        return self.calculate_status().value

    def to_dict(self) -> dict[str, Any]:
        """Convert item to dictionary including computed status."""
        d = asdict(self)
        d["status"] = self.status
        return d


@dataclass
class Distribution:
    """Represents an audit record of distributed stock."""
    id: Optional[int]
    item_id: int
    item_name: str
    quantity: int
    recipient: str
    date_given: str  # YYYY-MM-DD

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class CategorySummary:
    """Statistical summary for an individual category."""
    category: str
    lines: int
    received: int
    given: int
    in_stock: int
    share_of_stock_pct: float


@dataclass
class InventoryStats:
    """Aggregate statistics for the entire inventory system."""
    total_lines: int
    units_received: int
    units_in_stock: int
    units_given_out: int
    avg_units_per_line: float
    distribution_rate_pct: float
    top_donor: Optional[tuple[str, int]]
    count_low_stock: int
    count_out_of_stock: int
    count_expiring_soon: int
    count_expired: int
    category_summaries: list[CategorySummary]
