"""CLI interface, command-line argument parser, and interactive menu."""

from __future__ import annotations

import argparse
from datetime import date
import sys
from typing import Optional

from donation_inventory.models import Category
from donation_inventory.services import InventoryService
from donation_inventory.ui import (
    BOLD,
    CYAN,
    MAGENTA,
    YELLOW,
    colorize,
    confirm_prompt,
    print_banner,
    print_error,
    print_info,
    print_success,
    print_table,
    print_warning,
    prompt_string,
    status_badge,
)
from donation_inventory.validators import ValidationError


def build_parser() -> argparse.ArgumentParser:
    """Builds comprehensive command-line argument parser with subcommands."""
    parser = argparse.ArgumentParser(
        prog="donation-inventory",
        description="Donation Item Inventory Management System (Python 3.10+ CLI)",
    )
    subparsers = parser.add_subparsers(dest="subcommand", help="Available subcommands")

    # add
    p_add = subparsers.add_parser("add", help="Record a new donation item")
    p_add.add_argument("--name", "-n", required=True, help="Item name (2-60 chars)")
    p_add.add_argument("--category", "-c", required=True, choices=Category.list(), help="Item category")
    p_add.add_argument("--quantity", "-q", required=True, type=int, help="Quantity received (1-100000)")
    p_add.add_argument("--donor", "-d", required=True, help="Donor name or organisation")
    p_add.add_argument("--date", "-r", default=date.today().isoformat(), help="Date received (YYYY-MM-DD)")
    p_add.add_argument("--expiry", "-e", default=None, help="Expiry date (YYYY-MM-DD, optional)")

    # list
    p_list = subparsers.add_parser("list", help="List and search inventory items")
    p_list.add_argument("--search", "-s", default=None, help="Search term for item name or donor")
    p_list.add_argument("--category", "-c", default=None, choices=Category.list(), help="Filter by category")
    p_list.add_argument(
        "--status",
        choices=["In stock", "Low stock", "Out of stock", "Expiring soon", "Expired"],
        default=None,
        help="Filter by status",
    )
    p_list.add_argument("--page", "-p", type=int, default=1, help="Page number (default: 1)")
    p_list.add_argument("--page-size", type=int, default=10, help="Page size (default: 10)")

    # distribute
    p_dist = subparsers.add_parser("distribute", help="Record stock distribution to a recipient")
    p_dist.add_argument("--item-id", "-i", type=int, required=True, help="ID of item to distribute")
    p_dist.add_argument("--quantity", "-q", type=int, required=True, help="Quantity to distribute")
    p_dist.add_argument("--recipient", "-r", required=True, help="Recipient entity or person")
    p_dist.add_argument("--date", "-d", default=date.today().isoformat(), help="Distribution date (YYYY-MM-DD)")

    # history
    p_hist = subparsers.add_parser("history", help="View stock distribution audit history")
    p_hist.add_argument("--limit", "-l", type=int, default=50, help="Limit number of log entries")

    # delete
    p_del = subparsers.add_parser("delete", help="Delete an inventory item line")
    p_del.add_argument("--id", "-i", type=int, required=True, help="Item ID to delete")

    # summary
    subparsers.add_parser("summary", help="Display executive metrics and category summary")

    # export
    p_exp = subparsers.add_parser("export", help="Export inventory data to CSV, JSON, Markdown, or TXT")
    p_exp.add_argument(
        "--format",
        "-f",
        required=True,
        choices=["csv", "json", "md", "txt"],
        help="Target export format",
    )
    p_exp.add_argument("--output", "-o", default=None, help="Output destination file path")

    # import
    p_imp = subparsers.add_parser("import", help="Import donation records from CSV file")
    p_imp.add_argument("--file", "-f", required=True, help="Path to input CSV file")

    # seed
    subparsers.add_parser("seed", help="Populate database with 40 realistic sample records")

    # wipe
    p_wipe = subparsers.add_parser("wipe", help="Clear all database records")
    p_wipe.add_argument("--confirm", action="store_true", help="Confirm wipe without prompt")

    # interactive
    subparsers.add_parser("interactive", help="Start interactive terminal user interface")

    return parser


class InventoryCLI:
    """Handles CLI command dispatch and interactive menus."""

    def __init__(self, service: Optional[InventoryService] = None):
        self.service = service or InventoryService()

    def run(self, args: Optional[list[str]] = None) -> int:
        parser = build_parser()
        parsed = parser.parse_args(args)

        if not parsed.subcommand or parsed.subcommand == "interactive":
            return self.run_interactive()

        try:
            if parsed.subcommand == "add":
                item = self.service.add_item(
                    name=parsed.name,
                    category=parsed.category,
                    quantity=parsed.quantity,
                    donor=parsed.donor,
                    date_received=parsed.date,
                    expiry_date=parsed.expiry,
                )
                print_success(f"Added item #{item.id}: {item.name} ({item.stock} in stock).")

            elif parsed.subcommand == "list":
                self.cmd_list(parsed.search, parsed.category, parsed.status, parsed.page, parsed.page_size)

            elif parsed.subcommand == "distribute":
                dist = self.service.record_distribution(
                    item_id=parsed.item_id,
                    quantity=parsed.quantity,
                    recipient=parsed.recipient,
                    date_given=parsed.date,
                )
                print_success(f"Recorded distribution #{dist.id}: {dist.quantity}x '{dist.item_name}' to '{dist.recipient}'.")

            elif parsed.subcommand == "history":
                self.cmd_history(parsed.limit)

            elif parsed.subcommand == "delete":
                self.service.delete_item(parsed.id)
                print_success(f"Deleted item #{parsed.id}.")

            elif parsed.subcommand == "summary":
                self.cmd_summary()

            elif parsed.subcommand == "export":
                self.cmd_export(parsed.format, parsed.output)

            elif parsed.subcommand == "import":
                count, errs = self.service.import_csv(parsed.file)
                print_success(f"Successfully imported {count} items.")
                if errs:
                    print_warning(f"{len(errs)} rows skipped with errors:")
                    for e in errs:
                        print(f"  - {e}")

            elif parsed.subcommand == "seed":
                count = self.service.seed_sample_data()
                print_success(f"Loaded {count} sample records into inventory.")

            elif parsed.subcommand == "wipe":
                if parsed.confirm or confirm_prompt("Are you sure you want to delete ALL inventory and distribution records?"):
                    self.service.wipe_all_data()
                    print_success("All inventory and distribution history has been permanently deleted.")
                else:
                    print_info("Wipe operation cancelled.")

            return 0

        except ValidationError as ex:
            print_error(f"Validation failed:\n" + "\n".join(f"  • {e}" for e in ex.errors))
            return 1
        except Exception as ex:
            print_error(str(ex))
            return 1

    def cmd_list(self, search: Optional[str], category: Optional[str], status: Optional[str], page: int, page_size: int) -> None:
        items, total = self.service.list_items(search=search, category=category, status=status, page=page, page_size=page_size)
        headers = ["ID", "Item Name", "Category", "Stock / Rcvd", "Received Date", "Donor", "Status"]
        aligns = ["right", "left", "left", "right", "center", "left", "center"]

        rows = []
        for it in items:
            rows.append([
                it.id,
                it.name,
                it.category,
                f"{it.stock} / {it.received}",
                it.date_received,
                it.donor,
                status_badge(it.status),
            ])

        print_banner()
        filter_desc = []
        if search:
            filter_desc.append(f"search='{search}'")
        if category:
            filter_desc.append(f"category='{category}'")
        if status:
            filter_desc.append(f"status='{status}'")
        filt_str = f" [Filters: {', '.join(filter_desc)}]" if filter_desc else ""
        print_info(f"Showing page {page} ({len(items)} of {total} items){filt_str}:")
        print_table(headers, rows, aligns)

    def cmd_history(self, limit: int) -> None:
        dists = self.service.list_distributions(limit=limit)
        headers = ["Dist ID", "Date Given", "Item ID", "Item Name", "Qty Given", "Recipient"]
        aligns = ["right", "center", "right", "left", "right", "left"]
        rows = [[d.id, d.date_given, d.item_id, d.item_name, d.quantity, d.recipient] for d in dists]
        print_info(f"Distribution History (Latest {len(dists)}):")
        print_table(headers, rows, aligns)

    def cmd_summary(self) -> None:
        stats = self.service.get_stats()
        print_banner()
        print(colorize("--- INVENTORY KPI DASHBOARD ---", CYAN + BOLD))
        top_str = f"{stats.top_donor[0]} ({stats.top_donor[1]:,} units)" if stats.top_donor else "None"

        overview_headers = ["Metric", "Value"]
        overview_rows = [
            ["Total Item Lines", f"{stats.total_lines:,}"],
            ["Total Units Received", f"{stats.units_received:,}"],
            ["Total Units Distributed", f"{stats.units_given_out:,}"],
            ["Total Units in Stock", f"{stats.units_in_stock:,}"],
            ["Average Units / Line", f"{stats.avg_units_per_line:.1f}"],
            ["Distribution Rate", f"{stats.distribution_rate_pct:.1f}%"],
            ["Top Donor", top_str],
            ["Expired Items", colorize(str(stats.count_expired), YELLOW if stats.count_expired else "")],
            ["Out of Stock Items", colorize(str(stats.count_out_of_stock), YELLOW if stats.count_out_of_stock else "")],
            ["Low Stock Items (<=10)", colorize(str(stats.count_low_stock), YELLOW if stats.count_low_stock else "")],
            ["Expiring Soon (<=30d)", colorize(str(stats.count_expiring_soon), YELLOW if stats.count_expiring_soon else "")],
        ]
        print_table(overview_headers, overview_rows, ["left", "right"])

        print("\n" + colorize("--- CATEGORY BREAKDOWN ---", CYAN + BOLD))
        cat_headers = ["Category", "Lines", "Received", "Given Out", "In Stock", "Stock Share %"]
        cat_rows = []
        for c in stats.category_summaries:
            cat_rows.append([
                c.category,
                c.lines,
                f"{c.received:,}",
                f"{c.given:,}",
                f"{c.in_stock:,}",
                f"{c.share_of_stock_pct:.1f}%",
            ])
        print_table(cat_headers, cat_rows, ["left", "right", "right", "right", "right", "right"])

    def cmd_export(self, fmt: str, output: Optional[str]) -> None:
        default_files = {
            "csv": "inventory_export.csv",
            "json": "donation_backup.json",
            "md": "summary_report.md",
            "txt": "audit_log.txt",
        }
        dest = output or default_files[fmt]
        if fmt == "csv":
            path = self.service.export_csv(dest)
        elif fmt == "json":
            path = self.service.export_json(dest)
        elif fmt == "md":
            path = self.service.export_markdown(dest)
        elif fmt == "txt":
            path = self.service.export_audit_log(dest)
        else:
            raise ValueError(f"Unknown format: {fmt}")
        print_success(f"Exported data to {path}")

    # ------------------ Interactive Mode ------------------

    def run_interactive(self) -> int:
        print_banner()
        today_iso = date.today().isoformat()

        while True:
            print("\n" + colorize("=== MAIN MENU ===", BOLD + MAGENTA))
            print("  1. Record a New Donation")
            print("  2. View / Search Inventory Items")
            print("  3. Distribute Stock to Recipient")
            print("  4. View Distribution History")
            print("  5. View Executive Summary & Analytics")
            print("  6. Export Data (CSV / JSON / Markdown / TXT)")
            print("  7. Import Data from CSV")
            print("  8. Load 40 Sample Records (with Edge Cases)")
            print("  9. Delete an Item Line")
            print(" 10. Wipe All Data (Factory Reset)")
            print("  0. Exit")

            choice = prompt_string("\nEnter choice (0-10)", default="2")

            if choice == "0":
                print_info("Exiting Donation Inventory System. Goodbye!")
                return 0

            elif choice == "1":
                print("\n" + colorize("-- Record New Donation --", BOLD))
                name = prompt_string("Item Name (e.g. Winter blankets)")
                print(f"Categories: {', '.join(Category.list())}")
                cat = prompt_string("Category", default="Food")
                qty = prompt_string("Quantity (1-100,000)", default="10")
                donor = prompt_string("Donor Name")
                rcv_date = prompt_string("Date Received (YYYY-MM-DD)", default=today_iso)
                expiry = prompt_string("Expiry Date (optional, YYYY-MM-DD)", default="", allow_empty=True)
                try:
                    item = self.service.add_item(name, cat, qty, donor, rcv_date, expiry or None)
                    print_success(f"Item #{item.id} '{item.name}' added successfully!")
                except ValidationError as e:
                    print_error(f"Validation failed:\n" + "\n".join(f"  • {err}" for err in e.errors))

            elif choice == "2":
                q = prompt_string("Search keyword (or Enter for all)", default="", allow_empty=True)
                cat_filter = prompt_string("Category filter (or Enter for all)", default="", allow_empty=True)
                stat_filter = prompt_string("Status filter (In stock, Low stock, Out of stock, Expiring soon, Expired) or Enter for all", default="", allow_empty=True)
                self.cmd_list(
                    search=q or None,
                    category=cat_filter or None,
                    status=stat_filter or None,
                    page=1,
                    page_size=25,
                )

            elif choice == "3":
                print("\n" + colorize("-- Distribute Stock --", BOLD))
                item_id_str = prompt_string("Item ID to distribute from")
                try:
                    item_id = int(item_id_str)
                    item = self.service.get_item(item_id)
                    print_info(f"Selected: '{item.name}' ({item.category}) - Available stock: {item.stock}")
                    qty_str = prompt_string(f"Quantity to distribute (1-{item.stock})")
                    recipient = prompt_string("Recipient (person, shelter, family)")
                    dist_date = prompt_string("Distribution Date (YYYY-MM-DD)", default=today_iso)
                    dist = self.service.record_distribution(item_id, qty_str, recipient, dist_date)
                    print_success(f"Distributed {dist.quantity} units to '{dist.recipient}'. Remaining stock: {item.stock - dist.quantity}")
                except Exception as e:
                    print_error(f"Distribution error: {e}")

            elif choice == "4":
                self.cmd_history(limit=25)

            elif choice == "5":
                self.cmd_summary()

            elif choice == "6":
                print("\nFormats: csv, json, md, txt")
                fmt = prompt_string("Select format", default="csv").lower()
                out_path = prompt_string("Output filename (or Enter for default)", default="", allow_empty=True)
                try:
                    self.cmd_export(fmt, out_path or None)
                except Exception as e:
                    print_error(f"Export failed: {e}")

            elif choice == "7":
                csv_path = prompt_string("Enter path to CSV file")
                try:
                    count, errs = self.service.import_csv(csv_path)
                    print_success(f"Imported {count} items successfully.")
                    if errs:
                        print_warning(f"{len(errs)} skipped lines:")
                        for err in errs[:10]:
                            print(f"  • {err}")
                except Exception as e:
                    print_error(f"Import error: {e}")

            elif choice == "8":
                if confirm_prompt("Seed database with 40 realistic records & distribution history?", default=True):
                    count = self.service.seed_sample_data()
                    print_success(f"Successfully seeded {count} sample items!")

            elif choice == "9":
                del_id_str = prompt_string("Item ID to delete")
                try:
                    del_id = int(del_id_str)
                    if confirm_prompt(f"Confirm deletion of item #{del_id} and its distribution history?"):
                        self.service.delete_item(del_id)
                        print_success(f"Item #{del_id} deleted.")
                except Exception as e:
                    print_error(f"Delete failed: {e}")

            elif choice == "10":
                if confirm_prompt("ARE YOU SURE? This will permanently wipe all items and distributions."):
                    self.service.wipe_all_data()
                    print_success("Database wiped successfully.")
